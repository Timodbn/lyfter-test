<!DOCTYPE html>
<?php
	session_start();
	if (isset($_SESSION['Ingelogd']))
	{
		
	}
	else
	{
		$_SESSION["Ingelogd"]=0;
	}
?>
<html>
	<head>
		<title>Mcat Contact</title>
		<link rel="stylesheet" href="stylesheet.css"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<header>
		<center>
			<img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;">
		</center>
	</header>
	<body>
		<ul>
			<?php if ($_SESSION["Ingelogd"] == 1)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				} else
				{
				if ($_SESSION["Ingelogd"] == 2)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				}else
				{
				?><li style="float:right"><a href="dancelogin.php">Login</a></li><?php
				?><li style="float:right"><a href="danceregister.php">Register</a></li><?php
				}
				}
			?>
			<li><a href="dancehomepage.php"><b>Home</a></li>
			<li><a href="dancenewspage.php">News</a></li>
			<li><a class="active" href="dancecontactpage.php">Contact</a></li>
			<li><a href="danceticketpage.php">Tickets</a></li>
			<li><a href="dancelineuppage.php">Line-up</a></li>
		</ul>
		<center>
			<h1 class="white">Get in contact with us</h1>
			<h3 class="white"><ins>Feel free to ask us any questions!</ins></h3></br>
			<h5 class="white">
			<table class="socialicons">
				<tr>
					<td><center><a href="https://twitter.com/monstercat?lang=nl" target="_blank"><div class="fa fa-twitter" style="font-size:52px; aria-hidden="true"></div></a></center></td>
					<td><center><a href="https://www.facebook.com/monstercat/" target="_blank"><div class="fa fa-facebook-square" style="font-size:52px; aria-hidden="true"></div></a></center></td>
					<td><center><a href="mailto:info@monstercat.com?Subject=" target="_top"><div class="fa fa-envelope" style="font-size:52px; aria-hidden="true"></div></a></center></td>
					<td><center><a href="https://www.twitch.tv/monstercat" target="_blank"><div class="fa fa-twitch" style="font-size:52px; aria-hidden="true"></div></a></center></td>
					<td><center><a href="https://www.youtube.com/monstercat" target="_blank"><div class="fa fa-youtube" style="font-size:52px; aria-hidden="true"></div></a></center></td>
				</tr>
				<tr>
					<td><ins>Twitter</ins></td>
					<td><ins>Facebook</ins></td>
					<td><ins>Email</ins></td>
					<td><ins>Twitch</ins></td>
					<td><ins>Youtube</ins></td>
				</tr>
			</table>
			<br/><br/>
			<div id="map" style="width:400px;height:400px;background:white"></div>
			<script>
				function myMap() {
				var mapOptions = {
					center: new google.maps.LatLng(21.2842559, -157.8458345),
					zoom: 16,
					mapTypeId: google.maps.MapTypeId.HYBRID
				}
				var map = new google.maps.Map(document.getElementById("map"), mapOptions);
				}
			</script>
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAWl8j0g5LUPczivtTLBXIrWnoWYX9OCGs&callback=myMap"></script>
			<h2 class="white"><ins>Hawaii, Honolulu, Magic Island.</ins></h2>
		</center>
	</body>
</html>