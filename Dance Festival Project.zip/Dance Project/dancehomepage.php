<!DOCTYPE html>
<?php
	session_start();
	if (isset($_SESSION['Ingelogd']))
	{
		
	}
	else
	{
		$_SESSION["Ingelogd"]=0;
	}
?>
<html>
	<head>
		<title>Mcat Homepage</title>
		<link rel="stylesheet" href="stylesheet.css"/>
	</head>
	<header>
		<center>
			<img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;">
		</center>
	</header>
	<body>
		<ul>
			<?php if ($_SESSION["Ingelogd"] == 1)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				} else
				{
				if ($_SESSION["Ingelogd"] == 2)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				}else
				{
				?><li style="float:right"><a href="dancelogin.php">Login</a></li><?php
				?><li style="float:right"><a href="danceregister.php">Register</a></li><?php
				}
				}
			?>
			<li><a class="active" href="dancehomepage.php"><b>Home</a></li>
			<li><a href="dancenewspage.php">News</a></li>
			<li><a href="dancecontactpage.php">Contact</a></li>
			<li><a href="danceticketpage.php">Tickets</a></li>
			<li><a href="dancelineuppage.php">Line-up</a></li>
		</ul>
		<center>
			<h1 class="white">Tune into our Monstercat podcast</h1>
			<h3 class="white"><ins>Let's get the beat going!</ins></h3>
			<div class="squarebanner">
				<iframe frameborder="0" scrolling="no" src="http://twitch.tv/monstercat/chat?popout=" height="503" width="375"></iframe>
				<iframe src="http://player.twitch.tv/?channel=monstercat" height="500" width="890" allowfullscreen ></iframe>
			</div>
		</center>
	</body>
</html>