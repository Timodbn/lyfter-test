<!DOCTYPE html>
<?php
	session_start();
	if (isset($_SESSION['Ingelogd']))
	{
		
	}
	else
	{
		$_SESSION["Ingelogd"]=0;
	}
?>
<html>
	<head>
	<title>Mcat Lineup</title>
		<link rel="stylesheet" href="stylesheet.css"/>
	</head>
	<header>
		<center><img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;"></center>
	</header>
	<body>
		<ul>
			<?php if ($_SESSION["Ingelogd"] == 1)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				} else
				{
				if ($_SESSION["Ingelogd"] == 2)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				}else
				{
				?><li style="float:right"><a href="dancelogin.php">Login</a></li><?php
				?><li style="float:right"><a href="danceregister.php">Register</a></li><?php
				}
				}
			?>
			<li><a href="dancehomepage.php"><b>Home</a></li>
			<li><a href="dancenewspage.php">News</a></li>
			<li><a href="dancecontactpage.php">Contact</a></li>
			<li><a href="danceticketpage.php">Tickets</a></li>
			<li><a class="active" href="dancelineuppage.php">Line-up</a></li>
		</ul>
		<center>
			<h1 class="white">Check out our line-up</h1>
			<h3 class="white"><ins>There's gotta' be someone you know!</ins></h3>
			<div class="lineupsquare">
				<table>
					<tr>		
						<td>
							<a href="https://www.monstercat.com/artist/aero-chord">
								<div class="container">
									<img src="pictures/aerochord.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">AERO CHORD</div>
									</div>
								</div>
							</a>
						</td>			
						<td>
							<a href="https://www.monstercat.com/artist/anevo">
								<div class="container">
									<img src="pictures/anevo.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">ANEVO</div>
									</div>
								</div>
							</a>
						</td>				
						<td>
							<a href="https://www.monstercat.com/artist/pegboard-nerds">
								<div class="container">
									<img src="pictures/pegboard.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">PEGBOARD NERDS</div>
									</div>
								</div>
							</a>
						</td>			
						<td>
							<a href="https://www.monstercat.com/artist/tokyomachine">
								<div class="container">
									<img src="pictures/tokyo.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">TOKYO MACHINE</div>
									</div>
								</div>
							</a>
						</td>
					</tr>
					<tr>
						<td>
							<a href="https://www.monstercat.com/artist/tristam">
								<div class="container">
									<img src="pictures/tristam.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">TRISTAM</div>
									</div>
								</div>
							</a>
						</td>			
						<td>
							<a href="https://www.monstercat.com/artist/mr-fijiwiji">
								<div class="container">
									<img src="pictures/fijiwiji.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">FIJIWIJI</div>
									</div>
								</div>
							</a>
						</td>			
						<td>
							<a href="https://www.monstercat.com/artist/rezonate">
								<div class="container">
									<img src="pictures/rezonate.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">REZONATE</div>
									</div>
								</div>
							</a>
						</td>		
						<td>
							<a href="https://www.monstercat.com/artist/krewella">
								<div class="container">
									<img src="pictures/krewella.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">KREWELLA</div>
									</div>
								</div>
							</a>
						</td>
					</tr>
					<tr>
						<td>
							<a href="https://www.monstercat.com/artist/haywyre">
								<div class="container">
									<img src="pictures/heywyre.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">HAYWYRE</div>
									</div>
								</div>
							</a>
						</td>			
						<td>
							<a href="https://www.monstercat.com/artist/karma-fields">
								<div class="container">
									<img src="pictures/karmafields.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">KARMAFIELDS</div>
									</div>
								</div>
							</a>
						</td>			
						<td>
							<a href="https://www.monstercat.com/artist/hyper-potions">
								<div class="container">
									<img src="pictures/hyperpot.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">HYPERPOTIONS</div>
									</div>
								</div>
							</a>
						</td>
						<td>
							<a href="https://www.monstercat.com/artist/marshmello">
								<div class="container">
									<img src="pictures/marshmello.jpg" alt="Avatar" class="image" style="width:250px;height:250px">
									<div class="middle">
										<div class="text">MARSHMELLO</div>
									</div>
								</div>
							</a>
						</td>
					</tr>
				</table>
			</div>
		</center>
	</body>
</html>