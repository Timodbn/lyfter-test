<!DOCTYPE html>
<?php
session_start();
if (isset($_SESSION['Ingelogd']))
{
	
}
else
{
	$_SESSION["Ingelogd"]=0;
}
?>
<?php
include('db.php')
?>
<html>
	<head>
		<title>Mcat Homepage</title>
		<link rel="stylesheet" href="stylesheet.css"/>
	</head>
	<header>
		<center>
			<img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;">
		</center>
	</header>
	<body>
		<ul>
			<li><a href="dancehomepage.php"><b>Home</a></li>
			<li><a href="dancenewspage.php">News</a></li>
			<li><a href="dancecontactpage.php">Contact</a></li>
			<li><a href="danceticketpage.php">Tickets</a></li>
			<li><a href="dancelineuppage.php">Line-up</a></li>
			<li style="float:right"><a class="active" href="dancelogin.php">Login</b></a></li>
			<li style="float:right"><a href="danceregister.php">Register</a></li>
		</ul>
		<center>
			<h1 class="white">Login below to access other pages on our site</h1>
			<h3 class="white"><ins>Make sure to register before logging in!</ins></h3>
		</center>
	</br>
		<div class="loginsquare">
			<h2 class="black">Login:</h2>
			<form method="POST">
			<h4 class="black">
			<table>
				<tr>
					<td>Username:</td>
					<td><input type="text" name="TxTGebruikersnaam"/></br></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" name="TxtWachtwoord"/></br></td>
				</tr>
				<h2><tr><td><input type="submit" value="Sign-up" name="Verstuur"/></td></tr>
			</table>
		</div>
		<?php
			if(isset($_POST['Verstuur']))
			{
				$username = $_POST['TxTGebruikersnaam'];
				$password = $_POST['TxtWachtwoord'];
				$query = "SELECT * FROM signup WHERE Username= '$username' and Passwoord= '$password'";
				$result = mysqli_query($db, $query) or die(mysqli_error($db)); $count = mysqli_num_rows($result);
				if($count == 1)
				{
					$_SESSION['Username'] = $username;	
				}
				else
				{
					echo '<script language="javascript">'; 
					echo 'alert("Username and / or password incorrect! Make sure to register before logging in.")';
					echo '</script>';
				}
			}
			$query = "SELECT * FROM signup";
			$result = mysqli_query($db, $query);
			if (!$result)
			{
				echo 'Query failed!' . mysqli_error();
			}
			else
			{
				while($row = mysqli_fetch_array($result))
			{
			if(isset($_POST['Verstuur']))
			{
				if($_POST['TxTGebruikersnaam'] == $row['Username'] & $_POST['TxtWachtwoord'] == $row['Passwoord'])
					{
								$_SESSION['Username']=$row['Username'];
								if($_SESSION['Username'] == 'Admin')
								{
								$_SESSION["Ingelogd"]=2;
								Header ("Location: http://localhost/Leerjaar%201.2/Dance%20Project/dancehomepage.php");
								}else{
								$_SESSION["Ingelogd"]=1;
								Header ("Location: http://localhost/Leerjaar%201.2/Dance%20Project/dancehomepage.php");
						}
					}
			}
			}
		}
		?>
	</body>
</html>