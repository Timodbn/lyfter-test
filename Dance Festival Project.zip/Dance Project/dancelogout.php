<?php
	session_start();
	if (isset($_SESSION['Ingelogd']))
	{
		$_SESSION["Ingelogd"]=0;
		unset($_SESSION['Username']);
		Header ("Location: http://localhost/Leerjaar%201.2/Dance%20Project/dancehomepage.php");
	}
?>