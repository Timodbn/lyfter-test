<!DOCTYPE html>
<?php
	session_start();
	if (isset($_SESSION['Ingelogd']))
	{
		
	}
	else
	{
		$_SESSION["Ingelogd"]=0;
	}
?>
<html>
	<head>
	<title>Mcat News</title>
		<link rel="stylesheet" href="stylesheet.css"/>
	</head>
	<header>
		<center><img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;"></center>
	</header>
	<body>
		<ul>
			<?php if ($_SESSION["Ingelogd"] == 1)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				} else
				{
				if ($_SESSION["Ingelogd"] == 2)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				}else
				{
				?><li style="float:right"><a href="dancelogin.php">Login</a></li><?php
				?><li style="float:right"><a href="danceregister.php">Register</a></li><?php
				}
				}
			?>
			<li><a href="dancehomepage.php"><b>Home</a></li>
			<li><a class="active" href="dancenewspage.php">News</a></li>
			<li><a href="dancecontactpage.php">Contact</a></li>
			<li><a href="danceticketpage.php">Tickets</a></li>
			<li><a href="dancelineuppage.php">Line-up</a></li>
		</ul>
		<center>
			<h1 class="white">Check out the latest news</h1>
			<h3 class="white"><ins>Stay updated on when our tours are etc!</ins></h3>
		</center>
		<?php 
			include("db.php");
		?>
		<form method="POST">
		<?php
			if(isset($_POST['btn1']))
			{
				$Newstitel1 = $_POST['Newstitel1'];
				$Newsinhoud1 = $_POST['Newsinhoud1'];
				$query = "UPDATE news SET News_ID = 1, News_Items = '$Newsinhoud1', News_Titel = '$Newstitel1', Newsp_ID = 1 WHERE news . News_ID = 1;";
				
				mysqli_query($db, $query);
				echo '<script language="javascript">';
				echo 'alert("Uw nieuws item is geplaatst!")';
				echo '</script>';
			}
			if(isset($_POST['btn2']))
			{
				$Newstitel2 = $_POST['Newstitel2'];
				$Newsinhoud2 = $_POST['Newsinhoud2'];	
				$query = "UPDATE news SET News_ID = '2', News_Titel = '$Newstitel2', News_Items = '$Newsinhoud2', Newsp_ID = 2 WHERE news . News_ID = 2;";
				
				mysqli_query($db, $query);
				echo '<script language="javascript">';
				echo 'alert("Uw nieuws item is geplaatst!")';
				echo '</script>';
			}
			if(isset($_POST['btn3']))
				{
				$Newstitel3 = $_POST['Newstitel3'];
				$Newsinhoud3 = $_POST['Newsinhoud3'];
				$query = "UPDATE news SET News_ID = 3, News_Titel = '$Newstitel3', News_Items = '$Newsinhoud3', Newsp_ID = 3 WHERE news . News_ID = 3;";
				
				mysqli_query($db, $query);
				echo '<script language="javascript">';
				echo 'alert("Uw nieuws item is geplaatst!")';
				echo '</script>';
			}
		?>
		<?php if ($_SESSION["Ingelogd"] == 2)
		{
		?>
		<center>
			<div class="nieuwsitems1">
				<table>
					<tr><td><h1 class="black">Enter newsitems:</h1></td></tr>
				</table>
				<h3 class="nieuwsitems2"></h3>
				<table>
					<tr><td><h3 class="black">First item title:</h3></td></tr>
					<tr><td><input type="text" name="Newstitel1"></td></tr>
					<tr><td><h2 class="black">First content:</h2></td></tr>
					<tr><td><textarea type="text" name="Newsinhoud1" rows="10" cols="70"></textarea></td><tr>
					<tr><td><input type="submit" name="btn1"></td></tr>
				</table>
				<h3 class="nieuwsitems2"></h3>
				<table>
					<tr><td><h3 class="black">Second item title:</h3></td></tr>
					<tr><td><input type="text" name="Newstitel2"></td></tr>
					<tr><td><h2 class="black">Second content:</h2></td></tr>
					<tr><td><textarea type="text" name="Newsinhoud2" rows="10" cols="70"></textarea></td><tr>
					<tr><td><input type="submit" name="btn2"></td></tr>
				</table>
				<h3 class="nieuwsitems2"></h3>
				<table>
					<tr><td><h3 class="black">Third item title:</h3></td></tr>
					<tr><td><input type="text" name="Newstitel3"></td></tr>
					<tr><td><h2 class="black">Third content:</h2></td></tr>
					<tr><td><textarea type="text" name="Newsinhoud3" rows="10" cols="70"></textarea></td><tr>
					<tr><td><input type="submit" name="btn3"></td></tr>
				</table>
			</div>
		<br/>
		</center>
		<?php } ?>
		<?php
			$query = "SELECT * FROM news WHERE Newsp_ID = 1";
			$result = mysqli_query($db, $query);
			$row = mysqli_fetch_array($result);
			$titel = $row['News_Titel'];
			$item = $row['News_Items'];
			
			echo "<div class='niewskleur2'><div class='nieuwssquare'>".$titel .'<br>';
			echo "<div class='niewskleur'>".$item .'<br><hr></div>';
			
			$query = "SELECT * FROM news WHERE Newsp_ID = 2";
			$result = mysqli_query($db, $query);
			$row = mysqli_fetch_array($result);
			$titel = $row['News_Titel'];
			$item = $row['News_Items'];
			
			echo "<div class='niewskleur2'>".$titel .'<br></div>';
			echo "<div class='inewskleur'>".$item .'<br><hr></div>';
			
			$query = "SELECT * FROM news WHERE Newsp_ID = 3";
			$result = mysqli_query($db, $query);
			$row = mysqli_fetch_array($result);
			$titel = $row['News_Titel'];
			$item = $row['News_Items'];
			
			echo "<div class='niewskleur2'>".$titel .'<br></div>';
			echo "<div class='niewskleur'>".$item .'<br></div>';
		?>
	</body>
</html>