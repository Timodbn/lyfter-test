<!DOCTYPE html>
<?php
include("db.php");
?>
<html>
	<head>
		<title>Mcat Register</title>
		<link rel="stylesheet" href="stylesheet.css"/>
	</head>
	<header>
		<center>
			<img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;">
		</center>
	</header>
	<body>
		<ul>
			<li><a href="dancehomepage.php"><b>Home</a></li>
			<li><a href="dancenewspage.php">News</a></li>
			<li><a href="dancecontactpage.php">Contact</a></li>
			<li><a href="danceticketpage.php">Tickets</a></li>
			<li><a href="dancelineuppage.php">Line-up</a></li>
			<li style="float:right"><a href="dancelogin.php">Login</b></a></li>
			<li style="float:right"><a class="active" href="danceregister.php">Register</a></li>
		</ul>
		<center>
			<h1 class="white">Register below to access other pages on our site</h1>
			<h3 class="white"><ins>Make sure to register to make your order!</ins></h3>
		</center>
		</br>
		<div class="registersquare">
			<h2 class="black">Registration Form:</h2>
			<form method="POST">
			<h4 class="black">
			<table>
				<tr><td>Username:</td>
				<td><input type="text" name="TxTGebruikersnaam"Required></br></td></tr>
				<tr><td>Email:</td>
				<td><input type="text" name="TxTEmail"Required></br></td></tr>
				<tr><td>Password:</td>
				<td><input type="password" name="TxtWachtwoord"Required></br></tr></td>
				<tr><td>Confirm Password:</td></h4>
				<td><input type="password" name="TxtWachtwoord2"Required></tr></td>
				<h2><tr><td><input type="submit" value="Sign-up" name="Verstuur"/></td></tr>
			</table>
		</div>
		<div class="postcontent">
		<?php
		if(isset($_POST["Verstuur"]))
		{
			$username = $_POST['TxTGebruikersnaam'];
			$email = $_POST['TxTEmail'];
			$password = $_POST['TxtWachtwoord'];
			$confirm_password = $_POST['TxtWachtwoord2'];
			$query = "INSERT INTO signup (UID, Username, Passwoord, Email)";
			$query .= "VALUES (0, '$username', '$password', '$email')";	
			
			Header ("Location: http://localhost/Leerjaar%201.2/Dance%20Project/dancehomepage.php");
			mysqli_query($db, $query);
		}
		?>
					
		</div>
			</form>
	</body>
</html>