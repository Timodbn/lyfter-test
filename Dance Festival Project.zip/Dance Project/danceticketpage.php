<!DOCTYPE html>
<?php
	session_start();
	if (isset($_SESSION['Ingelogd']))
	{
		
	}
	else
	{
		$_SESSION["Ingelogd"]=0;
	}
?>
<?php
include('db.php')
?>
<html>
	<head>
	<title>Mcat Tickets</title>
		<link rel="stylesheet" href="stylesheet.css"/>
	</head>
	<header>
		<center><img src="pictures/headerbanner.png" alt="Headerbanner" style="width:901px;height:256px;"></center>
	</header>
	<body>
		<ul>
			<?php if ($_SESSION["Ingelogd"] == 1)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				} else
				{
				if ($_SESSION["Ingelogd"] == 2)
				{
				?><li style="float:right"><a href="dancelogout.php">Logout</a></li><?php
				?><li style="float:right"><a id="nohover"><?php echo "Welcome back: ". $_SESSION["Username"]?></a></li><?php
				}else
				{
				?><li style="float:right"><a href="dancelogin.php">Login</a></li><?php
				?><li style="float:right"><a href="danceregister.php">Register</a></li><?php
				}
				}
			?>
			<li><a href="dancehomepage.php"><b>Home</a></li>
			<li><a href="dancenewspage.php">News</a></li>
			<li><a href="dancecontactpage.php">Contact</a></li>
			<li><a class="active" href="danceticketpage.php">Tickets</a></li>
			<li><a href="dancelineuppage.php">Line-up</a></li>
		</ul>
		<center>
			<h1 class="white">Buy yourself our ticket for the newest festival</h1>
			<h3 class="white"><ins>Register for discount notifications!</ins></h3>
		</center>
		<div class="ticketsquare">
			<h2 class="zwart">Order tickets:</h2>
			<form method="POST">
			<h4 class="zwart">
				<table>
					<tr><td>Tickets:</td><td><select name="TxTtickets">
					<option value="Saturday">February 12th</option>
					<option value="Sunday">February 13th</option>
					<option value="Full-Weekend">February 12th & February 13th</option></select></td></tr>
					<tr><td>Amount:</td><td><input type="text" name="Txtamount"/></td></tr>
					<tr><td><input type="submit" value="Order" name="Verstuur"/></td></tr>
				</table>
				<table>
					<th>Prices per ticket:</th>
					<tr><td>Saturday</td><td>€29,99</td></tr>
					<tr><td>Sunday</td><td>€29,99</td></tr>
					<tr><td>Full-Weekend</td><td>€54,99</td></tr>
					</br><div class="setline"></div></br>
				</table>
				</br><div class="setline"></div></br>
				<table>
					<tr><td>Saturday: Regular concert on the 12th of April</td></tr>
					<tr><td>Sunday: Regular concert on the 13th of April</td></tr>
					<tr><td>Full-Weekend: Two concerts on the 12th- and 13th of April</td></tr>
					<tr><td>All concerts are from 2PM 'till 11PM, 2018.</td></tr>
				</table>
			</div>
			</center>
			<?php
			if(isset($_POST['Verstuur']))	
			{
				$tickettype = $_POST['TxTtickets'];
				$amount = $_POST['Txtamount'];
				
				if(isset($_SESSION["Username"]))
				{
					$username = $_SESSION["Username"];
					$query = "SELECT * FROM tickets WHERE soort= '$tickettype' ";
					$result = mysqli_query($db, $query) or die (mysqli_error($db));
					$row = mysqli_fetch_array($result);
					$TID = $row['TID'];
					$query2 = "SELECT * FROM signup WHERE Username= '$username' ";
					$result2 = mysqli_query($db, $query2) or die (mysqli_error($db));	
					$row2 = mysqli_fetch_array($result2);	
					$UID = $row2['UID'];	
					$query = "INSERT INTO orders VALUES (0, '$TID', '$UID', '$amount')";
					mysqli_query($db, $query);
					
					echo '<script language="javascript">';
					echo 'alert("Ticket has been bought and an email has been sent!")';
					echo '</script>'
					
					?><center><font color="white"><?php echo 'Ticket has been bought and an email has been sent!';
				}
				else
				{
					echo '<script language="javascript">';
					echo 'alert("You have to be logged in to buy a ticket!")';
					echo '</script>'
					?><center><font color="white"><?php echo 'You have to be logged in to buy a ticket!'; ?></font><?php
				}
			}?>
			</form>
	</body>
</html>