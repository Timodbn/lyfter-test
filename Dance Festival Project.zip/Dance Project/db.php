<?php
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpas = "";
	$dbname = "dance";
	$db = mysqli_connect($dbhost, $dbuser, $dbpas, $dbname);
	if(!$db)
	{
		echo mysqli_error ($db);
	}
?>